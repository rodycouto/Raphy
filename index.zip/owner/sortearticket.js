const Discord = require('discord.js')
const db = require('quick.db')

exports.run = async (client, message, args) => {

    if (message.author.id !== "451619591320371213") {
        message.delete().catch(err => { return })
        return message.inlineReply('⚠️ Este comando é um restrito.').then(msg => msg.delete({ timeout: 5000 }))
    }

    const embed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle('💰 Ticket Lotery Winner')
        .setDescription('658.989 Tickets foram comprados ao todo')
        .addField('🎫 Ticket', `452.413 - :id: 9S5D-C4DR-R0LA-V5A8\nEste usuário comprou ||Isso é secredo|| tickets.`)
        .addField('🌐 Servidor', 'Ignite Juniors Administration - :id: 836994921373368350')
        .addField('👤 Usuário', `Raffah#1751 - :id: 752952755798278186`)
        .addField('💸 Prêmio', `${db.get('loteria')} <:StarPoint:766794021128765469>MPoints`)

    return message.channel.send('<a:loading:834782920287846430> Embaralhando os tickets...').then(msg => msg.delete({ timeout: 7000 })).then(msg => msg.channel.send('<a:loading:834782920287846430> Obtendo um ticket aleatório...')).then(msg => msg.delete({ timeout: 15000 })).then(msg => msg.channel.send(embed)).then(msg => msg.channel.send('<a:loading:834782920287846430> Deletando todos os tickets...')).then(msg => msg.delete({ timeout: 5000 }))
}