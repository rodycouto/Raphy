exports.run = async (client, message, args) => {
    return message.inlineReply('Sistema de Música Fechado por que o *YouTube/Spotify/SoundCloud* não ajuda com a API')
}